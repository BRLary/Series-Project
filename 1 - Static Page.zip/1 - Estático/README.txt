This is the first version which is static. You do not have to run any database file to be able to check this version of the project.

This project was developed in portuguese language.





PT-BR

Esta � a primeira vers�o do projeto, ou seja, est�tica. N�o � necess�rio abrir arquivos de banco de dados para poder checar esta vers�o do projeto.

Projeto desenvolvido em portugu�s.