﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace prjSerie
{
    public partial class serie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int n = 0;

            #region Ligando ao banco

            clsBancoDeDados.clsBanco31586 ClsBanco = new clsBancoDeDados.clsBanco31586();

            ClsBanco.LinhaConexao("localhost", "root", "root", "prjserie");

            ClsBanco.Connect();

            if (ClsBanco.erroconexao == "")
            {
                lblErro.Text = "Conectado!";
            }
            else
            {
                lblErro.Text = ClsBanco.erroconexao;
            }

            #endregion

            Panel ClearFloats = new Panel(); // crio uma div para limpar os floats
            ClearFloats.ID = "Clear"; // dou um nome a ela
            ClearFloats.CssClass = "cls"; // aplico o css

            Panel FLOAT = new Panel();
            FLOAT.ID = "floating";
            FLOAT.CssClass = "fl";

            #region Tentar trazer o resumo
            try
            {
                if (Request["n"] != null)
                {
                    n = int.Parse(Request["n"].ToString());
                    MySqlDataReader dados = ClsBanco.Select("Select * from serie where cd_serie = " + n + ";");
                    if (dados.HasRows)
                    {
                        while (dados.Read())
                        {
                          lblResumo.Text = dados["ds_sinopse_serie"].ToString();
                          //ddlEpisodio.Controls.Add(dados["nm_episodio"].ToString();
                        }

                        dados.Close();
                    }
                    else
                    {
                        dados.Close();
                    }
                }
            }
                catch
                {
                    lblErro.Text = "Erro na volta dos dados!";
                    return;
                }

            #endregion

            #region Tentar trazer temporadas
            try
            {
                MySqlDataReader dados = ClsBanco.Select("Select distinct cd_temporada from episodio where cd_serie = " + n + ";");
                if (dados.HasRows)
                {
                    while (dados.Read())
                    {
                        ddlTemporada.Items.Add(new ListItem(dados["cd_temporada"].ToString()));
                    }

                    dados.Close();
                }
                else
                {
                    dados.Close();
                }
            }
            catch
            {
                lblErro.Text = "Erro na volta dos dados!";
                return;
            }
            #endregion

            #region Tentar trazer episódios
            try 
                 {
                     MySqlDataReader dados = ClsBanco.Select("Select * from episodio where cd_serie = " + n + ";");
                    if (dados.HasRows)
                    {
                        while (dados.Read())
                        {
                            ddlEpisodio.Items.Add(new ListItem(dados["nm_episodio"].ToString()));
                        }

                        dados.Close();
                    }
                    else
                    {
                        dados.Close();
                    }
                }
               catch
                {
                    lblErro.Text = "Erro na volta dos dados!";
                    return;
                }
            #endregion

            #region Tentar trazer os atores
            try
            {      string 
                    comando = "select * from ator_personagem ap join personagem p ";
                    comando += " on(ap.cd_personagem = p.cd_personagem) join ator a on (ap.cd_ator = a.cd_ator)";
                    comando += "join serie s on (p.cd_serie_origem = s.cd_serie) where cd_serie =" + n;

                    MySqlDataReader dados = ClsBanco.Select(comando);
                    
                    if (dados.HasRows)
                    {
                        while (dados.Read())
                        {
                            Panel ator = new Panel();
                            ator.ID = "ator" + dados["cd_ator"].ToString();
                            ator.CssClass = "ator";

                            Panel caixa_nome = new Panel();
                            caixa_nome.ID = "caixa_nome" + dados["cd_ator"].ToString();
                            caixa_nome.CssClass = "caixinha_nome";

                            Label nome = new Label();
                            nome.ID = "nome" + dados["cd_ator"].ToString();
                            nome.CssClass = "nome_da_serie";
                            nome.Text = dados["nm_ator"].ToString();

                            caixa_nome.Controls.Add(nome);
                            ator.Controls.Add(caixa_nome);
                            pnlElenco.Controls.Add(ator);
                        }

                        dados.Close();
                    }
                    else
                    {
                        dados.Close();
                    }                
                }
                catch
                {
                    lblErro.Text = "Erro na volta dos dados!";
                    return;
                }

             pnlElenco.Controls.Add(ClearFloats);

                #endregion

            #region Tentar trazer imagens
           

            #endregion



             for (int i = 1; i < 5; i++)
            {
                //ddlTemporada.Controls.Add(new ListItem);
            }



            #region Fechando o banco

            ClsBanco.Fechar();

            #endregion
        }
    }
}