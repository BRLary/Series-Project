﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;

namespace prjSerie
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            #region Ligando ao banco

            clsBancoDeDados.clsBanco31586 ClsBanco = new clsBancoDeDados.clsBanco31586();

            ClsBanco.LinhaConexao("localhost", "root", "root", "prjserie");

            ClsBanco.Connect();

            if (ClsBanco.erroconexao == "")
            {
                lblErro.Text = "Conectado!";
            }
            else
            {
                lblErro.Text = ClsBanco.erroconexao;
            }

            #endregion

            int n = 0;

            #region Criação das informações

            Panel ClearFloats = new Panel(); // crio uma div para limpar os floats
            ClearFloats.ID = "Clear"; // dou um nome a ela
            ClearFloats.CssClass = "cls"; // aplico o css

            Panel FLOAT = new Panel();
            FLOAT.ID = "floating";
            FLOAT.CssClass = "fl";

            MySqlDataReader dados = ClsBanco.Select("Select * from serie");

            if (dados.HasRows)
            {
                while (dados.Read())
                {
                    HyperLink caminho = new HyperLink();
                    caminho.ID = "caminho" + dados["cd_serie"].ToString();
                    n = int.Parse(dados["cd_serie"].ToString());
                    caminho.NavigateUrl = "serie.aspx?n=" + n;

                    Panel bloco = new Panel();
                    bloco.ID = "caixa" + dados["cd_serie"].ToString();
                    bloco.CssClass = "bloco fl";

                    Image imagem = new Image();
                    imagem.CssClass = "fotoProduto";
                    imagem.ID = "imagem" + dados["cd_serie"].ToString();

                    try
                    {
                        byte[] foto = (byte[])dados["img_serie"];
                        string base64String = Convert.ToBase64String(foto, 0, foto.Length);
                        imagem.ImageUrl = "data:image/jpeg;base64," + base64String;
                    }
                    catch
                    {
                       imagem.ImageUrl = "images/no_image_found.png"; 
                    }

                    Panel caixa_nome = new Panel();
                    caixa_nome.ID = "caixa_nome" + dados["cd_serie"].ToString();
                    caixa_nome.CssClass = "caixinha_nome";

                    Label nome = new Label();
                    nome.ID = "nome" + dados["cd_serie"].ToString();
                    nome.CssClass = "nome_da_serie";
                    nome.Text = dados["nm_serie"].ToString();

                    caixa_nome.Controls.Add(nome);
                    bloco.Controls.Add(caixa_nome);
                    bloco.Controls.Add(imagem);
                    caminho.Controls.Add(bloco);
                    pnlPrincipal.Controls.Add(caminho);

                }
            }
            if (!dados.IsClosed)
            {
                dados.Close();
            }

            pnlPrincipal.Controls.Add(ClearFloats);

            #endregion 

            //Response.Redirect("~/index.aspx");
                    
            #region Fechando o banco

            //if (ClsBanco.G == ConnectionState.Open)
            //{
                
            //}
            ClsBanco.Fechar();

            #endregion
        }
    }
}