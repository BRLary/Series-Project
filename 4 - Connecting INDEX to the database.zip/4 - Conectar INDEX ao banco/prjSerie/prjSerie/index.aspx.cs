﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace prjSerie
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Panel ClearFloats = new Panel(); // crio uma div para limpar os floats
            ClearFloats.ID = "Clear"; // dou um nome a ela
            ClearFloats.CssClass = "cls"; // aplico o css

            Panel FLOAT = new Panel();
            FLOAT.ID = "floating";
            FLOAT.CssClass = "fl";

            for (int i = 1; i <= 5; i++)
            {
                HyperLink caminho = new HyperLink();
                caminho.ID = "caminho" + i.ToString();
                caminho.NavigateUrl = "serie.aspx";

                Panel bloco = new Panel();
                bloco.ID = "caixa" + i.ToString();
                bloco.CssClass = "bloco fl";

                Panel caixa_nome = new Panel();
                caixa_nome.ID = "caixa_nome" + i.ToString();
                caixa_nome.CssClass = "caixinha_nome";

                Label nome = new Label();
                nome.ID = "nome" + i.ToString();
                nome.CssClass = "nome_da_serie";
                nome.Text = "SERIE'S NAME";

                caixa_nome.Controls.Add(nome);
                bloco.Controls.Add(caixa_nome);
                caminho.Controls.Add(bloco);
                pnlPrincipal.Controls.Add(caminho);

            }

            pnlPrincipal.Controls.Add(ClearFloats);
        }
    }
}