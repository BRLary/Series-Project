This is the 4th version of the project which which starts displaying content found in the database file.

In the previous file, there was only dynamic creation of the HTML objects. 
Now these objects are being populated by the content coming from the database.


PT-BR

Esta � a quarta vers�o do projeto, que come�a a exibir o conte�do encontrado no arquivo do banco de dados.

No arquivo anterior, apenas havia cria��o din�mica dos objetos HTML. 
Agora, estes objetos est�o sendo preenchidos pelo conte�do que vem do banco de dados.