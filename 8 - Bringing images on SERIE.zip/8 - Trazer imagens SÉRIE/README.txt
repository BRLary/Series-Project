This is the 7th version of the project which brings pictures from the database on SERIE page.


PT-BR

Esta � a sexta vers�o do projeto, que traz fotos do site do banco na p�gina da s�rie.