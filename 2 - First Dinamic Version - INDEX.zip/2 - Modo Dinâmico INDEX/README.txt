This is the second version of the project which starts using dinamic content. For this version, open a database plataform and run the mySQL file.
In this project, I used the plataform called MySQL Workbench.

- "series.sql" contains the creation of tables.
- "massadeteste.sql" contains some test datas to test the project.
- "prjSerie.sql" is the file of the whole database of the project.


PT-BR

Esta � a segunda vers�o do projeto que come�a a usar conte�do din�mico. Para esta vers�o, abra uma plataforma de banco de dados e execute o arquivo mySQL.
Neste projeto, usei a plataforma chamada MySQL Workbench.

- "series.sql" cont�m a cria��o de tabelas.
- "massadeteste.sql" cont�m alguns dados de teste para testar o projeto.
- "prjSerie.sql" � o arquivo de todo o banco de dados do projeto.