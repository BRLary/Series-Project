This is the third version of the project which continues using dinamic content but in the page on the page displaying the series data.

PT-BR

Esta � a terceira vers�o do projeto, que continua usando conte�do din�mico, mas na p�gina da p�gina que exibe os dados da s�rie.
