This is the 5th version of the project which which starts displaying content found in the database file on the SERIES page.


PT-BR

Esta � a quinta vers�o do projeto, que come�a a exibir o conte�do encontrado no arquivo do banco de dados na p�gina de S�RIES.