﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace clsBancoDeDados
{
    public class clsBanco31586
    {
        #region Abertuda da Conexão

        public string linhadeconexao = "";

        public string erroconexao = "";

        public void LinhaConexao(string vServer, string vUID, string vPassword, string vDatabase)
        { 
          linhadeconexao = "SERVER=" + vServer + ";UID=" + vUID + ";PASSWORD=" + vPassword + ";DATABASE=" + vDatabase; // linha para conectar com o banco
        }

        MySqlConnection conexao;

        public void Connect()

        {
            erroconexao = "";
            conexao = new MySqlConnection(linhadeconexao);
            
            try
            {
                conexao.Open();
            }
            catch 
            {
                erroconexao = "Não é possível conectar-se ao banco!";
                return;
            }

        }

        #endregion

        #region Consulta de Dados (SELECT)

        public MySqlDataReader Select(string command) // comando para ler dados
        {
            MySqlCommand cSQL = new MySqlCommand(command, conexao); // variavel com meu comando e minha conexão
            MySqlDataReader dados = cSQL.ExecuteReader();
            return dados;

        }

        public void Command(string command) // é void porque não precisa de RETORNO
        {
            MySqlCommand coSQL = new MySqlCommand(command, conexao); // comando e conexão
            coSQL.ExecuteNonQuery(); // executando meu comando
        }
        
        #endregion    



        #region Fechamento de Conexão

        public void Fechar()

        {
            if (conexao.State == ConnectionState.Open)

            {
                conexao.Close();
            }
            
        }

        #endregion

    }
}
